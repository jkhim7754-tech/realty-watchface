plugins {
    id("com.android.application")
}

android {
    namespace = "com.jkhim7754.blueocta.watchface2"
    compileSdk = 35

    signingConfigs {
        create("stableTest") {
            storeFile = file("../blue-octa-test.jks")
            storePassword = "blueoctatest"
            keyAlias = "blueocta"
            keyPassword = "blueoctatest"
        }
    }

    defaultConfig {
        applicationId = "com.jkhim7754.blueocta.watchface2"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "1.1"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("stableTest")
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("stableTest")
        }
    }
}
