plugins {
    id("com.android.application")
}

android {
    namespace = "com.jkhim7754.blueocta.watchface"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jkhim7754.blueocta.watchface"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}
