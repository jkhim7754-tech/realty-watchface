plugins {
    id("com.android.application")
}

android {
    namespace = "com.jkhim7754.gpttestwatchface"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jkhim7754.gpttestwatchface"
        minSdk = 33
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}
