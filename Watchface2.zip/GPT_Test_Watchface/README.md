# Blue Octa Digital

현재 GitHub Actions 설정에 바로 맞춘 프로젝트입니다.

기능:
- 디지털 시계
- 요일 / 월 / 일
- 배터리 %
- 날짜 탭: 캘린더
- 배터리 탭: 배터리 상태
- COMPASS 탭: Samsung Compass
- AOD에서는 배경과 부가기능을 끄고 시간만 표시
- 초 표시 없음

이 ZIP 파일 이름을 `Watchface2.zip`으로 유지하고 저장소의 기존 파일을 교체하면 됩니다.
