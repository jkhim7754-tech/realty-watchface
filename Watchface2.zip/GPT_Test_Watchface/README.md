# Blue Octa Digital — fixed test build

설치 거부 원인이 될 수 있었던 잘못된 COMPASS 텍스트 표현을 수정했습니다.

기능:
- 디지털 시계
- 요일 / 월 / 일
- 배터리 %
- 날짜 탭: 캘린더
- 배터리 탭: 배터리 상태
- COMPASS 탭: Samsung Compass
- AOD에서는 시간만 표시
- 초 표시 없음

## 중요
`blue-octa-test.jks`는 반복 테스트 시 서명이 바뀌지 않도록 넣은 공개 테스트 키입니다.
Google Play 정식 배포에는 절대 사용하지 말고, 정식 배포용 비공개 키를 새로 만들어야 합니다.
