# GPT Test Watchface

갤럭시 워치 / Wear OS용 시범 워치페이스입니다.

## 모바일 업로드
1. 이 ZIP을 휴대폰에서 압축 해제합니다.
2. 압축을 풀면 나오는 `GPT_Test_Watchface` 폴더 안의 파일과 폴더를 GitHub 저장소 최상단에 업로드합니다.
3. 기존 `.github/workflows/main.yml`은 삭제해도 됩니다.
4. 업로드 후 Actions에서 `Build Watch Face APK`가 자동 실행됩니다.
5. 완료된 실행의 Artifacts에서 `GPT-Test-Watchface-APK`를 받습니다.

주의: ZIP 파일 자체를 그대로 GitHub에 올리면 자동으로 풀리지 않습니다. 반드시 먼저 압축을 해제하세요.
